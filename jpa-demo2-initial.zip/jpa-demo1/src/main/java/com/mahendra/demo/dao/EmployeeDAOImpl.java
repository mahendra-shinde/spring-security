package com.mahendra.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.mahendra.demo.model.EmployeeEntity;

@Repository("empdao")
public class EmployeeDAOImpl implements EmployeeDAO {

	@PersistenceContext
	private EntityManager em;
	
	public EmployeeEntity find(Integer empId) {
		return em.find(EmployeeEntity.class,empId);
	}
	public void save(EmployeeEntity emp) {
		em.persist(emp);
	}

}
