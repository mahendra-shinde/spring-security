package com.mahendra.demo.dao;

import com.mahendra.demo.model.EmployeeEntity;

public interface EmployeeDAO {

	EmployeeEntity find(Integer empId);
	void save(EmployeeEntity emp);
}
