package com.mahendra.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mahendra.demo.dao.EmployeeDAO;
import com.mahendra.demo.model.EmployeeEntity;

@Service("empsvc")
public class EmpServiceImpl implements EmpService{

	@Autowired private EmployeeDAO dao;
	
	
	public void setDao(EmployeeDAO dao) {
		this.dao = dao;
	}

	public EmployeeEntity findById(Integer id) {
		return dao.find(id);
	}

	@Transactional
	public void save(EmployeeEntity emp) {
		dao.save(emp);
	}

	
}
