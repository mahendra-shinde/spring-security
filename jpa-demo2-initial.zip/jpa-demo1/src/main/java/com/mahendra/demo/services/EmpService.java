package com.mahendra.demo.services;

import com.mahendra.demo.model.EmployeeEntity;

public interface EmpService {

	public EmployeeEntity findById(Integer id);
	public void save(EmployeeEntity emp);
}
