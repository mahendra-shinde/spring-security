package com.mahendra.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mahendra.demo.dao.EmployeeDAO;
import com.mahendra.demo.model.EmployeeEntity;
import com.mahendra.demo.services.EmpService;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		EmpService svc = (EmpService) context.getBean("empsvc");

		EmployeeEntity em1 = new EmployeeEntity();
		em1.setEmail("emp1@yahoo.com");
		em1.setFirstName("Rahul");
		em1.setLastName("Modi");
		
		svc.save(em1);
		
		EmployeeEntity em2 = svc.findById(1);
		System.out.println("Name: "+em2.getFirstName());
	}

}
